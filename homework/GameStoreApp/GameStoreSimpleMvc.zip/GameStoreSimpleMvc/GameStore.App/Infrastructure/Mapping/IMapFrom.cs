﻿namespace GameStoreApp.App.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}
