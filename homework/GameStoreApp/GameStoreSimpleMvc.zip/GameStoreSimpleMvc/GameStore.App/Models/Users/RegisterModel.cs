﻿namespace GameStoreApp.App.Models.Users
{
    using GameStoreApp.App.Infrastructure.Validation;
    using GameStoreApp.App.Infrastructure.Validation.Users;

    public class RegisterModel
    {
        [Required]
        [Email]
        public string Email { get; set; }
        
        public string Name { get; set; }

        [Required]
        [Password]
        public string Password { get; set; }

        [Required]
        public string ConfirmPassword { get; set; }
    }
}
