﻿namespace GameStoreApp.App.Services
{
    using System.Linq;
    using GameStoreApp.App.Data;
    using GameStoreApp.App.Data.Models;
    using GameStoreApp.App.Services.Contracts;

    public class UserService : IUserService
    {
        private readonly GameStoreDbContext db;

        public UserService(GameStoreDbContext db)
        {
            this.db = db;
        }

        public bool Create(string email, string password, string name)
        {
            if (this.db.Users.Any(u => u.Email == email))
            {
                return false;
            }

            var isAdmin = !this.db.Users.Any();

            var user = new User
            {
                Email = email,
                Name = name,
                Password = password,
                IsAdmin = isAdmin
            };

            this.db.Add(user);
            this.db.SaveChanges();

            return true;
        }

        public bool UserExists(string email, string password)
            => this.db
                .Users
                .Any(u => u.Email == email && u.Password == password);
    }
}
