# GameStoreSimpleMvc
Simple MVC application built from scratch as an exercise for https://softuni.bg/trainings/1736/c-sharp-web-development-basics-september-2017. Enjoy! :)
