﻿namespace ModPanel.App.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}
